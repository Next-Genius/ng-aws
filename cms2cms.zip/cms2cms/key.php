<?php

header('X-Robots-Tag: noindex');

define('CMS2CMS_KEY', '01efe0c4fb62ade-37afa0bdf2ea084-b904fe6e1ccdeb4-bfd35b2c42e02ba4');
define('CMS2CMS_VERSION', '1.0.0');
define('CMS2CMS_BRIDGE_TYPE', 'cms2cms');
define('CMS2CMS_MINIMUM_PHP_VERSION', 5.1);

define('CMS_PATH', getcwd() . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR);
