<?php

header('X-Robots-Tag: noindex');

require 'bridge.php';
